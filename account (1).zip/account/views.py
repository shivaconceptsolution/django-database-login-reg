from django.shortcuts import render,redirect
from . models import Register 
def index(request):
    if request.method=="POST":
        r = Register(uname=request.POST["txtuser"],upass=request.POST["txtpass"],fname=request.POST["txtfname"],mobile=request.POST["txtmobile"])
        r.save()
        return render(request,"account/index.html",{"res":"Register successfully"})

    return render(request,"account/index.html")

def about(request):
    if request.method == "POST":
        r = Register.objects.filter(uname=request.POST["txtuser"],upass=request.POST["txtpass"]).values_list('id')
        if r.count()>0:
            request.session['uid'] = r[0][0]
           # request.session["uname"] = request.POST["txtuser"]
            return redirect('dashboard')
        else:
            res = "Invaid userid and password"
        return render(request,"account/about.html",{"key":res})        
    return render(request,"account/about.html")   

def contact(request):
    return render(request,"account/contact.html") 
def dashboard(request):
    if request.session.has_key('uid'):
        uid = request.session["uid"]
        data = Register.objects.get(pk=uid)
        return render(request,"account/dashboard.html",{"res":data})
    else:
        return redirect('/account')  

def editprofile(request):
    uid = request.session["uid"]
    data = Register.objects.get(pk=uid)
    if request.method=="POST":
         data.uname = request.POST["txtname"]
         data.upass = request.POST["txtpass"]
         data.fname = request.POST["txtfname"]
         data.mobile = request.POST["txtmobile"]
         data.save()
         return redirect('dashboard')
    else:
        return render(request,"account/profile.html",{"res":data})             
def logout(request):
    del request.session["uid"] 
    return redirect('/account')     
