from . import views
from django.urls import path
urlpatterns = [
path('',views.index,name='index'),
path('dashboard',views.dashboard,name='dashboard'),
path('editstu',views.editstu,name='editstu'),
path('deletestu',views.deletestu,name='deletestu'),
path('insertstu',views.insertstu,name='insertstu'),
path('logout',views.logout,name='logout')
]