from django.http import HttpResponse
from django.shortcuts import redirect, render
from .models import Principal
from account.models import Student
def index(request):
    if request.method=="POST":
        s = Principal.objects.filter(uname=request.POST["txtuser"],upass=request.POST["txtpass"])
        if s.count()>0:
            request.session["aid"] = request.POST["txtuser"]
            return redirect('dashboard')
        else:
            return HttpResponse("Invalid Userid and password")    
    return render(request,"principal/index.html")
def dashboard(request):
    if request.session.has_key('aid'):
       sessusers =  request.session["aid"]
       stu = Student.objects.all()
       return render(request,"principal/dashboard.html",{'key':sessusers,'stu':stu})
    else:
        return redirect('/principal') 
def editstu(request):
   if request.method=="POST":
        stu= Student.objects.get(pk=request.POST["txtid"])
        stu.sname=request.POST["txtsname"]
        stu.branch=request.POST["txtbranch"]
        stu.fees=request.POST["txtfees"]
        stu.save()
        return redirect('dashboard')

   stu= Student.objects.get(pk=request.GET["q"])
   return render(request,"principal/editstu.html",{"res":stu})
def deletestu(request):
    pass
def logout(request):
    del request.session['aid']
    return redirect('/principal')           