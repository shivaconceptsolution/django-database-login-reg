from django.db import models

class Principal(models.Model):
    uname=models.CharField(max_length=10)
    upass=models.CharField(max_length=10,default="")
