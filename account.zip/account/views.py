from django.http import HttpResponse
from django.shortcuts import render,redirect
from . models import Register,Student 
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
def index(request):
    if request.method=="POST":
      #  r = Register(uname=request.POST["txtuser"],upass=request.POST["txtpass"],fname=request.POST["txtfname"],mobile=request.POST["txtmobile"])
       # r.save()
        user = User.objects.create_user(request.POST["txtuser"], request.POST["txtemail"], request.POST["txtpass"])
        user.first_name=request.POST["txtfname"]
        user.last_name=request.POST["txtlname"]
        user.save()
        return render(request,"account/index.html",{"res":"Register successfully"})

    return render(request,"account/index.html")

def logincode(request):
    if request.method == "POST":
        user = authenticate(username=request.POST["txtuser"], password=request.POST["txtpass"])
       # r = Register.objects.filter(uname=request.POST["txtuser"],upass=request.POST["txtpass"]).values_list('id')
        if user is not None:
            login(request, user)
            request.session["uname"] = request.POST["txtuser"]
            return redirect('/account/dashboard')
        else:
            res = "Invaid userid and password"
        return render(request,"account/about.html",{"key":res})        
    return render(request,"account/about.html")   

def contact(request):
    return render(request,"account/contact.html") 
@login_required(login_url='/account/logincode')    
def dashboard(request):
    return render(request,"account/dashboard.html")
   

def editprofile(request):
    uid = request.session["uid"]
    data = Register.objects.get(pk=uid)
    if request.method=="POST":
         data.uname = request.POST["txtname"]
         data.upass = request.POST["txtpass"]
         data.fname = request.POST["txtfname"]
         data.mobile = request.POST["txtmobile"]
         data.save()
         return redirect('dashboard')
    else:
        return render(request,"account/profile.html",{"res":data})             
def logoutcode(request):
    #del request.session["uname"] 
    logout(request)
    return redirect('/account')     


def insert(request):
    s = Student(rno=1234,sname='xyz',branch='cs',fees=45000)
    s.save()
    return HttpResponse("Data Inserted Successfully")