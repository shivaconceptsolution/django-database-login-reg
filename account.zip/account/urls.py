from . import views
from django.urls import path
urlpatterns = [
path('',views.index,name='index'),
path('logincode',views.logincode,name='logincode'),
path('contact',views.contact,name='contact'),
path('dashboard',views.dashboard,name='dashboard'),
path('logoutcode',views.logoutcode,name='logoutcode'),
path('editprofile',views.editprofile,name='editprofile'),
path('insert',views.insert,name='insert')

]